package sod.service;

import sod.smartphone.AccessManager;
import sod.smartphone.ServerInfo;


public class ConnectionBean {
	public static final int SERVERPORT = 30331;
	public static String SERVERIP = "192.168.0.16";
	public static AccessManager client;
	public static ConnectionBean con;
	public static ServerInfo ServerInfomation;
}
