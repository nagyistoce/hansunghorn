
package com.sgsong.Draw;

public class SG_PT
{
	public int nX;
	public int nY;	
	
	public SG_PT()
	{		
	}
}