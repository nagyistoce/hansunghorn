
package com.sgsong.Game;

public class BoardCard
{	
	public int nID;	
	public int nPosX;
	public int nPosY;

	public boolean bExist;
	public int nNumber;
	

}