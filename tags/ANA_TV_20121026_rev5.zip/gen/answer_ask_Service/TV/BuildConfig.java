/** Automatically generated file. DO NOT MODIFY */
package answer_ask_Service.TV;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}