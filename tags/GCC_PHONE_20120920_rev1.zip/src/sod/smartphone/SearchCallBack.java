package sod.smartphone;

public interface SearchCallBack {
	void onSearch(ServerInfo info);
}
