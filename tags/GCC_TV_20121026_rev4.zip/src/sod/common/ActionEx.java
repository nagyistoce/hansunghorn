package sod.common;

public interface ActionEx {
	void work(Object arg);
}
