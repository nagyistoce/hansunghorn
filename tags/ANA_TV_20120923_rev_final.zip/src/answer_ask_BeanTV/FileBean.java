package answer_ask_BeanTV;

import java.util.HashMap;

import android.R.integer;

public class FileBean {
	public static String Topic = "";
	public static HashMap<String, HashMap<String, Integer>> hashmap = new HashMap<String, HashMap<String, Integer>>();
	public static HashMap<String, HashMap<String, Integer>> hashtemp = new HashMap<String, HashMap<String, Integer>>();
	// public static;
	public static integer count = new integer();

}
