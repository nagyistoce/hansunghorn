package answer_ask_BeanTV;

import java.util.HashMap;
import java.util.Vector;



public interface DataSturct {
	final static Vector<String> vector = new Vector<String>();
	public HashMap<String, String> hashmap=new HashMap<String, String>();
	public static Vector<GraphBean> dataVector = new Vector<GraphBean>();
	
	
}
 