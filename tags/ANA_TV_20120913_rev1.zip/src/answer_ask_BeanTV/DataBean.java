package answer_ask_BeanTV;

public class DataBean {
	public static String Message="";
	public static String Topic="";
	public static int AnswerCount=0;
	public static int ChartPage=0;
	public static int MaxPage=0;
	public static int data_index=-1;
}
