
package com.sgsong.GameCommand;

public class CMD_INFO
{
	public boolean bSet;
	public long startTime;
	public int	nID;
	
	public CMD_INFO()
	{
		bSet = false;
		startTime = 0;
		nID = -1;
	}
}