
package com.sgsong.Game;

public class FindCardInfo
{	
	public boolean bFind;

	public int nSameCount;
	public int nDestPosX;
	public int nDestPosY;
	
	public FindCardInfo()
	{		
	}	
}