
package com.sgsong.Draw;

public class SG_COLOR
{
	public float fRed;
	public float fGreen;
	public float fBlue;
	public float fAlpha;
	
	public SG_COLOR()
	{		
	}
}