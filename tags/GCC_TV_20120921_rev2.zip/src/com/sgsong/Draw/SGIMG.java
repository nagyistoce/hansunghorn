
package com.sgsong.Draw;

public class SGIMG
{	
	public int pImage;

	public int nTexID;
	public int nID;
	public int nImgStartX;
	public int nImgStartY;

	public int nWidth;
	public int nHeight;

	public int nTexWidth;
	public int nTexHeight;
	
	public SGIMG()
	{
		
	}	
}