package sod.common;

public interface Disposable {
	void dispose();
}
